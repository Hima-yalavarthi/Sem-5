function res = norm2d(fin)

res = fin/max(abs(fin(:)));