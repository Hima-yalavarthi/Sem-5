function img = reconstructFreqImage(modeAmp,FreqComps,indxToUse)

[sx,sy,~] = size(FreqComps);

img_Components = zeros(sx,sy,length(indxToUse));
for indx = 1:length(indxToUse)
    img_Components(:,:,indx) = modeAmp(indxToUse(indx))*FreqComps(:,:,indxToUse(indx));
end
img = 2*abs(sum(img_Components,3));

% figure,imshow3(img)
end