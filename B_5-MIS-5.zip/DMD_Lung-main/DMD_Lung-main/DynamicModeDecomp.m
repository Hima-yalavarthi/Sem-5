function [Phi_hat, omega, lambda, b, freq, Xdmd_hat, r] = MyDynamicModeDecomp(X, dt, nstacks)
    % Stack the data matrix
    if nstacks > 1
        X_aug = [];
        for st = 1:nstacks
            X_aug = [X_aug; X(:, st:end-nstacks+st)];
        end
        X1 = X_aug(:, 1:end-1);
        X2 = X_aug(:, 2:end);
    else
        X1 = X(:, 1:end-1);
        X2 = X(:, 2:end);
    end
    m = size(X1, 2);

    % DMD
    [U, D, ~] = eig(X1 * X1', 'vector'); % Eigen decomposition of X1 * X1'
    A_tilde = U' * X2 * U * diag(1./D);  % Build the transformed matrix A_tilde

    % Select the modes
    r = 15; % You can adjust this value
    if r >= size(U, 2)
        r = size(U, 2);
    end

    U_r = U(:, 1:r);
    D_r = diag(D(1:r));

    % Compute Phi_hat and eigenvalues
    Phi_hat = X2 * U_r / D_r;
    lambda = diag(D_r);
    omega = log(lambda) / dt;

    % Compute DMD mode amplitudes
    x1 = X1(:, 1);
    b = Phi_hat \ x1;

    % Compute frequencies
    freq = atan2(imag(lambda), real(lambda)) / (2 * pi * dt);

    % DMD reconstructions
    time_dynamics = zeros(r, m);
    t = (0:m) * dt;
    for iter = 1:m
        time_dynamics(:, iter) = (b .* exp(omega * t(iter)));
    end
    Xdmd_hat = Phi_hat * time_dynamics;
end
