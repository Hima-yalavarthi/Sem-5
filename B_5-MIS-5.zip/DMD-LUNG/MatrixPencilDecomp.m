function [Z , Amp, freq ,r ] = MatrixPencilDecomp(data, t)
% [Z, Amp, freq] = MatrixPencilDecomp(data, t, r)
% Matrix Pencil Decomposition. Estimates the "Z" matrix, amplitudes and the 
% frequencies.
%
% INPUTS:
% 
% data  = 1D vector containing the time-series data (Nx1)
% t     = Time vector (Nx1)
%
% 
% OUTPUTS:
%
% Z     = The poles matrix
% Amp   = The amplitudes
% freq  = The frequencies in Hertz 
%
% References:
% Sarkar, T.K. and Pereira, O.
% Using the Matrix Pencil Method to Estimate the Parameters of a Sum
% of Complex Exponentials.
% IEEE Antennas and Propagation Magazine, Vol. 37, No 1, Feb. 1995
%
% Matti Taskinen, Rolf Nevanlinna Institute, University of Helsinki
% Implementation of Matrix Pencil method.
% https://groups.google.com/g/comp.soft-sys.matlab/c/GXuKJLnuD2I
%
% Bauman, G. and Bieri, O. (2017), Matrix pencil decomposition of 
% time-resolved proton MRI for robust and improved assessment of pulmonary
% ventilation and perfusion. Magn. Reson. Med., 77: 336-342. 
% https://doi.org/10.1002/mrm.26096
%
% Fernández Rodríguez, A., de Santiago Rodrigo, L., López Guillén, E. et al.
% Coding Prony’s method in MATLAB and applying it to biomedical signal 
% filtering. BMC Bioinformatics 19, 451 (2018). 
% https://doi.org/10.1186/s12859-018-2473-y
%
% W. Trinh and T. Overbye, "Comparison of Dynamic Mode Decompositon and 
% Iterative Matrix Pencil Method for Power System Modal Analysis," 
% 2019 International Conference on Smart Grid Synchronized Measurements and
% Analytics (SGSMA), 2019, pp. 1-6, doi: 10.1109/SGSMA.2019.8784536.
%
%
% Efe Ilicak, 30/10/2022.

% Make sure time vector is a column vector
if size(t,1)<size(t,2)
    t = t';
end

st = length(data); % Matrix pencil only handles a 1D time-vector
L = floor(st/2); % Pencil parameter (L=st/2 for Cramer-Rao bound)
dt = t(2)-t(1); % Sampling period (assumed to be fixed during experiment)

Y = hankel(data(1:end-L),data(end-L:end));  % Form the Hankel Matrix

% SVD 
[U, S, V] = svd(Y, 'econ');

% ss = diag(S);
% r = sum(ss>(ss(1).^(1/10))); % one-tenth of max in log scale as threshold

ss = diag(S);
% r  = min(sum((ss./ss(1))>10^(-3)),15); 
r  = sum((ss./ss(1))>(3*10^(-3))); 


% NN = length(Y); 
% %% AIC
% for k=0:L-1
%     itc(k+1)=-2*NN*sum(log(ss(k+1:L))) ...
%         + 2*NN*(L-k)*log((sum(ss((k+1):L))/(L-k))) + 2*k*(2*L-k);
% end
% [~, tempI]=min(itc); 
% r=tempI-1;
% %% MDL
% for k=0:L-1
%     itc(k+1)=-NN*sum(log(ss((k+1):L))) + NN*(L-k)*log((sum(ss((k+1):L))/(L-k))) ...
%         + k*(2*L-k)*log(NN)/2;
% end
% [~, tempI]=min(itc); 
% r=tempI-1;

% rank truncation (according to Sarkar, rank trunction is done here)
Ur = U(:, 1:r); 
Sr = S(1:r, 1:r);
Vr = V(:, 1:r);

% Break the Hankel Matrix into two with rank truncation
Y1 = Ur*Sr*Vr(1:L,:)';
Y2 = Ur*Sr*Vr(2:L+1,:)';

% Find signal poles via eigenvalue decomposition
Atilde = pinv(Y1)*Y2; 
d = eig(Atilde);

% Order the eigenvalues
[~,orderIndex] = sort(d,'descend'); 

dOrdered = d(orderIndex);

% Select the top "r" modes
z = dOrdered(1:r);

b = 1/dt * log(z);

% Respective frequencies
freq = atan2(imag(z),real(z))/(2*pi*dt);

% Z matrix 
Z = exp(t*b.');

% Amplitude
Amp = Z\data;

