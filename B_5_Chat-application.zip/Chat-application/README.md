#Batch B_5

##Topic: Chat - Application

We developed an application that allowed two users to connect after taking the IP address and port that would be used for communication.

To run the application the following commands are to be run:

- `python server.py`
- `python client.py`

Once you enter the name in the terminal (or command prompt in case of Windows) a tkinter frame will open up, asking for the IP address and port info.



