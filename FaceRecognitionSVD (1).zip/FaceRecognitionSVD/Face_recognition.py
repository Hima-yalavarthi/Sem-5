import cv2
import numpy as np
import os

def read_image(file_path):
    # Read the image
    img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)

    # Check if the image is loaded successfully
    if img is None:
        print(f"Error loading image: {file_path}")
        return None

    # Resize the image
    img = cv2.resize(img, (100, 100), interpolation=cv2.INTER_AREA)

    return img.flatten()

def face_recognition(train_path):
    # Reading training images
    train_images = []
    for filename in os.listdir(train_path):
        train_images.append(read_image(os.path.join(train_path, filename)))

    # Convert images to a NumPy array
    train_images = np.array(train_images).T

    # Subtract mean from all images for normalization
    mu = np.mean(train_images)
    train_images = train_images - mu

    # SVD function
    u, s, v = np.linalg.svd(train_images, full_matrices=False)

    # Initialize webcam
    cap = cv2.VideoCapture(0)  # 0 corresponds to the default camera

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        # Convert the frame to grayscale
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Resize the frame
        gray_frame = cv2.resize(gray_frame, (100, 100), interpolation=cv2.INTER_AREA)

        # Flatten the frame
        test_image = gray_frame.flatten()

        # Subtract mean
        test_image = test_image - mu

        # Project the normalized test image onto the eigenspace
        test_x = np.dot(test_image, u)

        # Dot product of all the training images and U matrix
        dot_train = np.dot(train_images.T, u)

        # Subtracting two dot products
        sub = dot_train - test_x

        # Finding norm of all the columns
        answer = np.linalg.norm(sub, axis=1)

        # Finding the minimum answer
        index = np.argmin(answer)

        # Checking for corresponding image for the minimum answer
        predicted_face = os.listdir(train_path)[index]
        print("The predicted face is:", predicted_face)

        # Display the frame
        cv2.imshow('Webcam', frame)

        # Break the loop when 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close all OpenCV windows
    cap.release()
    cv2.destroyAllWindows()

# Example usage:
train_folder = 'dataimage'
face_recognition(train_folder)
