import streamlit as st
from PIL import Image
import io
def decode_image(img):
    """
    Check the red portion of an image (r, g, b) tuple for
    hidden message characters (ASCII values)
    """
    width, height = img.size
    msg = ""
    index = 0
    for row in range(height):
        for col in range(width):
            try:
                r, g, b = img.getpixel((col, row))
            except ValueError:
                # need to add transparency a for some .png files
                r, g, b, a = img.getpixel((col, row))		
            if row == 0 and col == 0:
                length = r
            elif index <= length:
                msg += chr(r)
            index += 1
    return msg

st.title('Image Steganography Decoder')

uploaded_file = st.file_uploader("Choose an image...", type="png")
if uploaded_file is not None:
    img_data = uploaded_file.read()
    img_decoded = Image.open(io.BytesIO(img_data))
    message = decode_image(img_decoded)
    st.write("Hidden message:", message)
