from PIL import Image

def encode_image(img, message):
    """
    Use the red portion of an image (r, g, b) tuple to
    hide the message string characters as ASCII values
    """
    length = len(message)
    if length > 255:
        print("Text too long! (don't exceed 255 characters)")
        return False
    if img.mode != 'RGB':
        print("Image needs to be RGB")
        return False
    encoded = img.copy()
    width, height = img.size
    index = 0
    for row in range(height):
        for col in range(width):
            r, g, b = img.getpixel((col, row))
            if row == 0 and col == 0 and index < length:
                asc = length
            elif index <= length:
                c = message[index -1]
                asc = ord(c)
            else:
                asc = r
            encoded.putpixel((col, row), (asc, g , b))
            index += 1
    return encoded

img = Image.open("red.jpg")
message = "this sentence is hidden in plain sight"
img_encoded = encode_image(img, message)
if img_encoded:
    img_encoded.save("output.png")
    print("Image saved as 'output.png'")
