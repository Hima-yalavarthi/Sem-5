# Crime trends analysis in the city of Baltimore

Dataset Download link:  https://data.world/data-society/city-of-baltimore-crime-data

Follow the steps below to use the project:

Step 1: Set Up MySQL Database
Make sure you have a MySQL database set up with the appropriate user credentials. You will need to specify the database host, user, password, and name in the main.ipynb file.

import mysql.connector

db_connection = mysql.connector.connect(
  host="YOUR_MYSQL_HOST”, # Replace with your MySQL host
  user="YOUR_MYSQL_USER”, # Replace with your MySQL user
  password="YOUR_MYSQL_PASSWORD”, # Replace with your MySQL password
  database="YOUR_MYSQL_DATABASE” # Replace with your MySQL database name
)

cursor = db_connection.cursor()


# ...(rest of the code for creating the table and importing CSV data)

cursor.close()
db_connection.close()

In the above code snippet, change the host, user, password, and database details. Create a database in MySQL before running the script.

Step 2: Specify CSV File Path
In the same main.ipynb file, specify the path of the CSV file you want to import

import csv
import mysql.connector

# ... (previous code)

csv_data = csv.reader(open('YOUR_CSV_FILE_PATH'))  # Replace with your CSV file path
next(csv_data)

# ... (rest of the code for importing CSV data)

cursor.close()
db_conn.close()

print("CSV Imported")

Step 3: Configure Apache Spark with JDBC Connector
Configure Apache Spark to connect to the MySQL database using JDBC. Provide the database details, including host, user, password, and name.


from pyspark.sql import SparkSession
from pyspark import SparkConf
from pyspark.sql import SQLContext

# ... (previous code)

# MySQL configurations
mysql_hostname = "YOUR_MYSQL_HOST"  # Replace with your MySQL host
mysql_port = 3306
mysql_database = "YOUR_MYSQL_DATABASE"  # Replace with your MySQL database name
mysql_table = "crimedata1"
mysql_user = "YOUR_MYSQL_USER"  # Replace with your MySQL user
mysql_password = "YOUR_MYSQL_PASSWORD"  # Replace with your MySQL password

# ... (rest of the code for connecting to MySQL using JDBC)

df.printSchema()

Make sure to replace placeholders like YOUR_MYSQL_HOST, YOUR_MYSQL_USER, YOUR_MYSQL_PASSWORD, YOUR_MYSQL_DATABASE, and YOUR_CSV_FILE_PATH with your specific configurations.

Now, you should be able to run the main.ipynb file successfully to import data into the MySQL database and connect Apache Spark with JDBC.



