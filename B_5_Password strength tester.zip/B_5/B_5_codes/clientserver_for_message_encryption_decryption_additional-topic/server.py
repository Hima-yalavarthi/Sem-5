import socket
from cryptography.fernet import Fernet

# Generate a random key for AES encryption
key = Fernet.generate_key()
fernet = Fernet(key)
print(f"Key: {key}")
# Create a server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('localhost', 12345)
server_socket.bind(server_address)
server_socket.listen(1)

print("Server is waiting for a connection...")
client_socket, client_address = server_socket.accept()

print("Client connected")

while True:
    message = client_socket.recv(1024)
    if not message:
        break

    decrypted_message = fernet.decrypt(message).decode()
    print(f"Received: {decrypted_message}")

client_socket.close()
server_socket.close()
