import socket
from cryptography.fernet import Fernet

# Client-side key should match the server's key
key = b'Cu3R6AqzyB6Iv35-uaAc8cmgOoNimILG_dQygueo1_4='
fernet = Fernet(key)

# Create a client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = ('localhost', 12345)

client_socket.connect(server_address)

while True:
    message = input("Enter a message (or 'exit' to quit): ")
    if message == 'exit':
        break

    encrypted_message = fernet.encrypt(message.encode())
    client_socket.send(encrypted_message)

client_socket.close()
