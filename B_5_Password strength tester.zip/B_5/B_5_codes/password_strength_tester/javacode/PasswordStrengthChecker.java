import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;

public class PasswordStrengthChecker {
    public static void main(String[] args) {
        checkPasswordStrength();
    }

    public static void checkPasswordStrength() {
        while (true) {
            System.out.println("***********");
            System.out.println("PASSWORD STRENGTH CHECKER");
            System.out.println("***********\n");

            boolean common = false; // Initialize common as false

            // Load common passwords from a file
            Set<String> commonPasswords = new HashSet<>();
            // Replace with actual file loading logic
            // Example: commonPasswords.add("password1");
            // Example: commonPasswords.add("123456");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a password: ");
            String password = scanner.nextLine();

            if (commonPasswords.contains(password)) {
                System.out.println("This is a common password. Please choose a stronger one.");
            } else {
                clearScreen();

                // Salt generation
                String salt = generateSalt();

                // Hash the password with salt
                String hashedPassword = hashPassword(password, salt);

                // Print salt and hashed password (you should store them securely)
                System.out.println("Salt: " + salt);
                System.out.println("Hashed Password: " + hashedPassword);


                int excess = password.length() - 6;
                int baseScore = 50;
                int numUpper = 0;
                int numSymbol = 0;
                int numLower = 0;
                int numDigit = 0;

                int bonusExcess = 3;
                int bonusUpper = 4;
                int bonusNumbers = 5;
                int bonusSymbols = 5;
                int bonusCombo = 0;
                int bonusFlatLower = 0;
                int bonusFlatNumber = 0;

                for (char ch : password.toCharArray()) {
                    if (Character.isDigit(ch)) {
                        numDigit++;
                    } else if (Character.isLowerCase(ch)) {
                        numLower++;
                    } else if (Character.isUpperCase(ch)) {
                        numUpper++;
                    } else if (ch >= '!' && ch <= '/') {
                        numSymbol++;
                    }
                }

                if (numUpper > 0 && numDigit > 0 && numSymbol > 0) {
                    bonusCombo = 25;
                } else if ((numUpper > 0 && numDigit > 0) || (numUpper > 0 && numSymbol > 0) || (numDigit > 0 && numSymbol > 0)) {
                    bonusCombo = 15;
                }

                int score = baseScore + (excess * bonusExcess) + (numUpper * bonusUpper) +
                        (numDigit * bonusNumbers) + (numSymbol * bonusSymbols) +
                        bonusCombo + bonusFlatLower + bonusFlatNumber;

                System.out.print("Checking Password Strength...");
                for (int i = 0; i < 3; i++) {
                    System.out.print("█");
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println();

                System.out.println();
                if (score < 50) {
                    System.out.println("Password Status: Weak");
                } else if (score >= 50 && score < 75) {
                    System.out.println("Password Status: Average");
                } else if (score >= 75 && score < 100) {
                    System.out.println("Password Status: Strong");
                } else if (score >= 100) {
                    System.out.println("Password Status: Secure");
                }

                // Now, calculate and display entropy
                int R = 26 + 21;
                double entropy = Math.log(Math.pow(R, password.length())) / Math.log(2);
                System.out.println("The entropy of this password is " + entropy);

                // Recheck password strength based on entropy
                recheckPasswordStrength(entropy);
            }

            System.out.print("Do you want to generate a password again (y/n): ");
            String op = scanner.nextLine();
            if (!op.toLowerCase().equals("y")) {
                return; // Use 'return' to exit the function
            }
        }
    }

    private static String generateSalt() {
        StringBuilder salt = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) { // 16 characters long salt
            char randomChar = (char) (random.nextInt(95) + 32); // Generate random printable ASCII characters
            salt.append(randomChar);
        }
        return salt.toString();
    }

    private static String hashPassword(String password, String salt) {
        String saltedPassword = password + salt;

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(saltedPassword.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                String hex = String.format("%02x", b);
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void recheckPasswordStrength(double entropy) {
        if (entropy > 0 && entropy <= 35) {
            System.out.println("Password Status (Based on Entropy): Very weak");
        } else if (entropy >= 36 && entropy <= 59) {
            System.out.println("Password Status (Based on Entropy): Weak");
        } else if (entropy >= 60 && entropy <= 119) {
            System.out.println("Password Status (Based on Entropy): Strong");
        } else if (entropy >= 120) {
            System.out.println("Password Status (Based on Entropy): Very strong");
        } else {
            System.out.println("Password Status (Based on Entropy): Retype the password");
        }
    }

    private static void clearScreen() {
        System.out.print("*");
    }
}
