import socket

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = '192.168.43.2'  # Replace with the actual IP address of the server
    port = 12345

    try:
        client_socket.connect((host, port))
    except Exception as e:
        print(f"Error: {e}")
        return

    while True:
        password = input("Enter Password: ")
        
        if password.lower() == 'exit':
            # User wants to exit the session
            client_socket.send(password.encode('utf-8'))
            break

        client_socket.send(password.encode('utf-8'))

        response = client_socket.recv(1024).decode('utf-8')
        print(response)

    client_socket.close()

if __name__ == "__main__":
    main()
