import socket
import math
import random

def is_common_password(password, common_passwords):
    return password in common_passwords

def calculate_entropy(password):
    R = 26 + 21
    entropy = math.log(math.pow(R, len(password))) / math.log(2)
    return entropy

def main(password):
    common_passwords = set()
    with open('C:\\Users\\DELL\\Desktop\\common passwords.txt', 'r') as file:
        common_passwords.update(line.strip() for line in file)

    if is_common_password(password, common_passwords):
        return "This is a common password. Please choose a stronger one."

    strength =recheck_password_strength(password)
    return strength

def recheck_password_strength(password):
    # Define your password strength criteria
    length_criteria = 8  # Minimum length requirement
    has_digit = False
    has_upper = False
    has_lower = False
    has_special = False

    # Check password length
    if len(password) < length_criteria:
        return "Weak: Password is too short."

    # Check for digit, uppercase, lowercase, and special characters
    for char in password:
        if char.isdigit():
            has_digit = True
        elif char.isupper():
            has_upper = True
        elif char.islower():
            has_lower = True
        elif char in "!@#$%^&*()_+-=[]{}|;:',.<>?":
            has_special = True

    # Assess the password strength based on criteria
    if has_digit and has_upper and has_lower and has_special:
        return "Strong: Password meets all criteria."
    elif has_digit and has_upper and has_lower:
        return "Moderate: Password lacks special characters."
    else:
        return "Weak: Password does not meet all criteria."


    entropy = calculate_entropy(password)
    return recheck_password_strength(entropy)

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = '192.168.43.2'  # Listen on all available network interfaces
    port = 12345

    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Server is listening on {host}:{port}")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")

        password = client_socket.recv(1024).decode('utf-8')
        response = main(password)
        if response is not None:
            client_socket.send(response.encode('utf-8'))

        client_socket.close()

if __name__ == "__main__":
    start_server()
